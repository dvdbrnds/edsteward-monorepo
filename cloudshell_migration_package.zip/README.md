# CloudShell Database Migration

## Quick Start:

1. Extract this ZIP file in CloudShell
2. Run: bash cloudshell_migration_setup.sh
3. Follow the instructions

## Files included:
- cloudshell_migration_setup.sh: Setup script
- sql_dump/: Database schema and user data
- exports/: Additional data files

## Connection Details:
- Host: edsteward-db.cwv4g6g0yzmg.us-east-1.rds.amazonaws.com
- Database: postgres
- User: postgres
- SSL Mode: prefer

This package migrates your local database to AWS RDS.
