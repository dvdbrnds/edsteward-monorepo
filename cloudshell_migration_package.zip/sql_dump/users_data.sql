--
-- PostgreSQL database dump
--

-- Dumped from database version 16.8
-- Dumped by pg_dump version 16.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, password, role, department, email, "firstName", "lastName", external_id, provider_id, identity_provider, last_login, created_at, updated_at) FROM stdin;
5	nasol@moravian.edu	4f09114c36bfd8bce96204888921752aebb6a4d26842746255d405733ad5305a3bba415fe60523b8ea87425e93bea4275ab4368e298b2cc8d2c0b2f8b736acd1.ec07d9e5935ec88a460022b62913dfde	admin	Compliance		\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
7	leahn	89d1677273cf096733b7ebf1debb057e69a60ba4720252296366b37819f23fdc9704c7ce6cd1c1f5b21b76b14a08bfe46d78efa0023fb02a613562f176eeb251.60f43f7f991a731dbf6f60c39f124c38	admin	leahn		\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
8	leahnaso	1c9d95a0b94e2aa56b9a1c6d2eadcae930b301cfbeeaedced1d28ddd3fc6c06150041471a3553b9d9b7d2ef310c85598e66c01e5e6b9f9606306b7d2bb701cfd.f59210d79fec350e37e1b36c55eae1e1	admin	Compliance	nasol@moravian.edu	\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
10	sharontest	a6c15631205a4bea6a2b1904a179e87b3b6005a83d0109fd2092fc0956efba8acc5924007e7569179c80c44df3202ac1e30d195d5718c4c5703df0d8f4473467.64812ca8a4ad8fd2717452f5bb7feede	user	IR	mauss@moravian.edu	\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
13	sharonadmin	1443c0935be1a3a5007a5f918074b309e9e19c06e5ba93f95cd6ffd6f7ecec3c328017ea74cfd0030a231f641cdbb03dc729bd9a80ef3aee7b7158500ef2c09a.bacc51fda3c0591035a37238988e6b37	admin	IR	mauss@moravian.edu	\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
14	davehome	6c8ed6f7170d3c540adaf429b13a665a071c11f01094830d394388d1a00405c516f725b58140cb29b9f7e0b6ab7e249d67222809a1f16de1df825c67493ab454.596e555dfa89f8e45c1c05422062c3ed	user	IT	brandesd@gmail.com	\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
15	edingerp	4c02bcad5be4acfeebb8b3942888eac4bc3c5ee7605a8b2556f5cd4e94e236ad443e0b0b2626fb60d2151e4fc4c65b0ed911d800fd0875d93ff24c913292ec72.ff3fb2713f66dcd52295433aadcdd6ad	admin	IT	edingerp@moravian.edu	\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
16	DMariano44	0a3f9f85a40337c89d8c52072f2a2ff29057324086d51dd19709c9a0668f135eecddd0c46495a798e2bb6b54745f9681d5a00eb3bf340f30183c83aadcbe83a3.93efcdc9d98daf4cc1bdd75c052585ad	user	HR	marianod@moravian.edu	\N	\N	\N	\N	\N	\N	2025-03-04 14:49:15.36756	2025-03-04 14:49:15.36756
12	Jim Beers	e3d2e552c882a896695e4456cb8ce0b79fd4fd818050457c337ad8bd6f2f2ff1b163e2a13c23f53a90253049c169f4b8ad74afa062167376e2a7101af078f76a.66ff9ea9aa8229cf1cf8c669e0b0d841	admin	Information Technology	beersj@moravian.edu	\N	\N	\N	\N	\N	2025-03-14 21:33:41.211	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
11	meyerg	ecc25fa743e1ae817f61139c79d00b9026cf7a45a42ef303e0e37212b73df28cf592f339b82b84f0678b205ea8fc6f0cbbb090d2e55538061ede7b645dd7809d.9723cce57d5a78c6b31f543cd3a96a1b	admin	Community Wellness	meyerg@moravian.edu	\N	\N	\N	\N	\N	2025-03-04 21:28:58.292	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
6	dvdbrnds	783782f8f254ca4880d60753314b2d648ed30795c856c2b011cae841749b77e3a76461bbb333e1af95db563cdd25d4737f7bfd664ee59dbede1cff31e1c00285.609a61a8a0c4d147ee28cf63830ec8bc	admin	IT	brandesd@moravian.edu	David	Brandes	\N	\N	\N	2025-03-24 20:27:34.664	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
17	lilythedog	04a49a673966819b8a508ded8f80c024426911488ce5f60a9dccba8534831f73ada754843199469d69418d6d4c01f3ea13602183013ed7f9a91af68da93fc053.125307e92837a903a9cde80a43cc5c3b	user	dog affaris	lilythedog@moravian.edu	lily	thedog	\N	\N	\N	\N	2025-03-13 14:59:40.961081	2025-03-13 14:59:40.961081
4	davey	557f98f852351b360acc1fb240062eca4dcd4ae48c781b544f16af9934679e1dd0d3c95e8ef2e8ddbe4da681f4b63d4e8d467190c945ba6df9df83453150dc33.234792cff19ffdd124063d215010c06a	user			\N	\N	\N	\N	\N	\N	2025-03-04 14:30:48.855809	2025-03-04 14:30:49.04378
18	test3	78dc27d6c2dc3a603c20a69f272a6318858a42fdfb5252e311ec7846134483331cf474750d7d7175f95d4ab070206ed60a23d89652a1eb59f9db8a0efef5e32d.34288acf1bb7b35cd05fad4d419567b4	admin	IT	test3@gmail.com	dave	test3	\N	\N	\N	\N	2025-03-24 18:18:05.089863	2025-03-24 18:18:05.089863
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: neondb_owner
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- PostgreSQL database dump complete
--

